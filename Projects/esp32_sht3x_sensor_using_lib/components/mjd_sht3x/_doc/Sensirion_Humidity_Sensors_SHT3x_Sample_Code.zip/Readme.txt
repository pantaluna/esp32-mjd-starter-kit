1. Download and install the Microcontroller Development Kit for ARM (MDK-ARM). 
   Version: 5.xx
   https://www.keil.com/demo/eval/arm.htm 

2. Download and install "MDK Version 5 - Legacy Support". 
   http://www2.keil.com/mdk5/legacy/